@echo off
chcp 65001 >nul
title n8n ETF Local Runner Bridge
echo ======================================================
echo  正在啟動 n8n stock02.py 本地執行橋接服務...
echo  監聽 Port: 8088
echo  n8n 容器呼叫位址: http://host.docker.internal:8088/run
echo ======================================================
python server.py
pause
