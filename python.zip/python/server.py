"""
n8n 本地 Python 執行橋接服務 (ETF Local Bridge Runner)
供 n8n 透過 HTTP Request 節點直接呼叫執行 stock02.py
"""
import http.server
import json
import logging
from stock02 import fetch_etf_data

PORT = 8088
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(message)s")


class ETFRunnerHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ["/run", "/run-stock02", "/"]:
            logging.info("收到來自 n8n 的執行請求，開始執行 stock02.py 爬蟲...")
            try:
                data = fetch_etf_data(export_excel=True)
                response_body = json.dumps(data, ensure_ascii=False).encode("utf-8")

                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(response_body)))
                self.end_headers()
                self.wfile.write(response_body)
                logging.info(f"爬取完成，已將 {data['total_count']} 筆資料回傳給 n8n。")
            except Exception as e:
                logging.error(f"執行 stock02.py 發生錯誤: {e}")
                err_data = {"status": "error", "message": str(e)}
                err_body = json.dumps(err_data).encode("utf-8")
                self.send_response(500)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(err_body)))
                self.end_headers()
                self.wfile.write(err_body)
        elif self.path == "/health":
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"OK")
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        # 簡化日誌
        return


if __name__ == "__main__":
    server_address = ("0.0.0.0", PORT)
    httpd = http.server.HTTPServer(server_address, ETFRunnerHandler)
    print(f"======================================================")
    print(f" ETF 本地執行橋接服務已啟動！")
    print(f" 監聽 Port: {PORT}")
    print(f" n8n 呼叫網址: http://host.docker.internal:{PORT}/run")
    print(f"======================================================")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n服務已停止。")
